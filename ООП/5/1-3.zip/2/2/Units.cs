namespace units
{
    public enum Units
    {
        Metric,  
        Imperial 
    }
    
    public enum DeviceType
    {
        LENGTH,
        MASS
    }
}